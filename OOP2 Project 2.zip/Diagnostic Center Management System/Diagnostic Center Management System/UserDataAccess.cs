﻿namespace Diagnostic_Center_Management_System
{
    internal class UserDataAccess
    {
    }
}