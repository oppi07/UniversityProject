
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vaccine Registration and Management System</title>
    <link rel="stylesheet" href="Rstyle.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
                <div>
                    <div class="title"></div>
                    <p>SUCCESSFULLY REGISTERED</p>
                    <br><br>
                    <li>
                        <a href="index.php">CLICK HERE</a> TO GO TO HOME PAGE
                    </li>

                </div>
    

</body>

</html>